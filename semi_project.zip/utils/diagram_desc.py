# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 17:10:40 2023

@author: Jung
"""

import streamlit as st

def desc():
    st.image('./images/diagram.jpg', use_column_width = True)