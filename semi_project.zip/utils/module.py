# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 10:42:14 2023

@author: Jung
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.font_manager import FontProperties
from matplotlib import font_manager, rc


def get_data(file_path):
    df = pd.read_excel(file_path)
    df.drop(df.index[0:3], inplace=True)
    df = df.rename(columns=df.iloc[0])
    df.drop(df.index[0], inplace=True)
    df = df[df['매출액 점유율'] != 0]
    df = df.reset_index(drop=True)
    df.drop(df.index[-1], inplace=True)
    return df['매출액'].sum(), df['관객수'].sum()

movie_sales_2018, movie_audience_2018 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018.xlsx')
movie_sales_2019, movie_audience_2019 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019.xlsx')
movie_sales_2020, movie_audience_2020 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020.xlsx')
movie_sales_2021, movie_audience_2021 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021.xlsx')
movie_sales_2022, movie_audience_2022 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022.xlsx')
movie_audience = [movie_audience_2018, movie_audience_2019, movie_audience_2020, movie_audience_2021, movie_audience_2022]
movie_sales = [movie_sales_2018, movie_sales_2019, movie_sales_2020, movie_sales_2021, movie_sales_2022]

movie_audience_Korea_2018, movie_sales_Korea_2018 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_한국.xlsx')
movie_audience_Korea_2019, movie_sales_Korea_2019 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_한국.xlsx')
movie_audience_Korea_2020, movie_sales_Korea_2020 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_한국.xlsx')
movie_audience_Korea_2021, movie_sales_Korea_2021 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_한국.xlsx')
movie_audience_Korea_2022, movie_sales_Korea_2022 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_한국.xlsx')
movie_audience_Korea = [movie_audience_Korea_2018, movie_audience_Korea_2019, movie_audience_Korea_2020, movie_audience_Korea_2021, movie_audience_Korea_2022]
movie_sales_Korea = [movie_sales_Korea_2018, movie_sales_Korea_2019, movie_sales_Korea_2020, movie_sales_Korea_2021, movie_sales_Korea_2022]

movie_audience_foreign_2018, movie_sales_foreign_2018 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_외국.xlsx')
movie_audience_foreign_2019, movie_sales_foreign_2019 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_외국.xlsx')
movie_audience_foreign_2020, movie_sales_foreign_2020 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_외국.xlsx')
movie_audience_foreign_2021, movie_sales_foreign_2021 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_외국.xlsx')
movie_audience_foreign_2022, movie_sales_foreign_2022 = get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_외국.xlsx')
movie_audience_foreign = [movie_audience_foreign_2018, movie_audience_foreign_2019, movie_audience_foreign_2020, movie_audience_foreign_2021, movie_audience_foreign_2022]
movie_sales_foreign = [movie_sales_foreign_2018, movie_sales_foreign_2019, movie_sales_foreign_2020, movie_sales_foreign_2021, movie_sales_foreign_2022]



def get_data_COVID19_2020(file_path):
    df = pd.read_excel(file_path)
    covid_2020 = df[df['전국 기준일'].str.startswith(('20.', '2020.'))]['전국 추가 확진']
    covid_2020 = pd.DataFrame(covid_2020)
    covid_2020_number = covid_2020['전국 추가 확진'].sum()
    return covid_2020_number

def get_data_COVID19_2021(file_path):
    df = pd.read_excel(file_path)
    covid_2021 = df[df['전국 기준일'].str.startswith(('2021.'))]['전국 추가 확진']
    covid_2021 = pd.DataFrame(covid_2021)
    covid_2021_number = covid_2021['전국 추가 확진'].sum()
    return covid_2021_number

def get_data_COVID19_2022(file_path):
    df = pd.read_excel(file_path)
    covid_2022 = df[df['전국 기준일'].str.startswith(('2022.'))]['전국 추가 확진']
    covid_2022 = pd.DataFrame(covid_2022)
    covid_2022_number = covid_2022['전국 추가 확진'].sum()
    return covid_2022_number

covid_2020_number = get_data_COVID19_2020('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_number = get_data_COVID19_2021('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_number = get_data_COVID19_2022('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')

covid_number = [covid_2020_number, covid_2021_number, covid_2022_number]


def get_data_COVID19_month_2020_01(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_01 = df5[df5['전국 기준일'].str.startswith(('20.01', '2020.01'))]['전국 추가 확진']
    covid_2020_01 = pd.DataFrame(covid_2020_01)
    covid_2020_01_number = covid_2020_01['전국 추가 확진'].sum()
    return covid_2020_01_number

def get_data_COVID19_month_2020_02(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_02 = df5[df5['전국 기준일'].str.startswith(('20.02', '2020.02'))]['전국 추가 확진']
    covid_2020_02 = pd.DataFrame(covid_2020_02)
    covid_2020_02_number = covid_2020_02['전국 추가 확진'].sum()
    return covid_2020_02_number

def get_data_COVID19_month_2020_03(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_03 = df5[df5['전국 기준일'].str.startswith(('2020.03'))]['전국 추가 확진']
    covid_2020_03 = pd.DataFrame(covid_2020_03)
    covid_2020_03_number = covid_2020_03['전국 추가 확진'].sum()
    return covid_2020_03_number
  
def get_data_COVID19_month_2020_04(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_04 = df5[df5['전국 기준일'].str.startswith(('2020.04'))]['전국 추가 확진']
    covid_2020_04 = pd.DataFrame(covid_2020_04)
    covid_2020_04_number = covid_2020_04['전국 추가 확진'].sum()
    return covid_2020_04_number
 
def get_data_COVID19_month_2020_05(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_05 = df5[df5['전국 기준일'].str.startswith(('2020.05'))]['전국 추가 확진']
    covid_2020_05 = pd.DataFrame(covid_2020_05)
    covid_2020_05_number = covid_2020_05['전국 추가 확진'].sum()
    return covid_2020_05_number

def get_data_COVID19_month_2020_06(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_06 = df5[df5['전국 기준일'].str.startswith(('2020.06'))]['전국 추가 확진']
    covid_2020_06 = pd.DataFrame(covid_2020_06)
    covid_2020_06_number = covid_2020_06['전국 추가 확진'].sum()
    return covid_2020_06_number
  
def get_data_COVID19_month_2020_07(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_07 = df5[df5['전국 기준일'].str.startswith(('2020.07'))]['전국 추가 확진']
    covid_2020_07 = pd.DataFrame(covid_2020_07)
    covid_2020_07_number = covid_2020_07['전국 추가 확진'].sum()
    return covid_2020_07_number

def get_data_COVID19_month_2020_08(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_08 = df5[df5['전국 기준일'].str.startswith(('2020.08'))]['전국 추가 확진']
    covid_2020_08 = pd.DataFrame(covid_2020_08)
    covid_2020_08_number = covid_2020_08['전국 추가 확진'].sum()
    return covid_2020_08_number

def get_data_COVID19_month_2020_09(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_09 = df5[df5['전국 기준일'].str.startswith(('2020.09'))]['전국 추가 확진']
    covid_2020_09 = pd.DataFrame(covid_2020_09)
    covid_2020_09_number = covid_2020_09['전국 추가 확진'].sum()
    return covid_2020_09_number

def get_data_COVID19_month_2020_10(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_10 = df5[df5['전국 기준일'].str.startswith(('2020.10'))]['전국 추가 확진']
    covid_2020_10 = pd.DataFrame(covid_2020_10)
    covid_2020_10_number = covid_2020_10['전국 추가 확진'].sum()
    return covid_2020_10_number

def get_data_COVID19_month_2020_11(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_11 = df5[df5['전국 기준일'].str.startswith(('2020.11'))]['전국 추가 확진']
    covid_2020_11 = pd.DataFrame(covid_2020_11)
    covid_2020_11_number = covid_2020_11['전국 추가 확진'].sum()
    return covid_2020_11_number

def get_data_COVID19_month_2020_12(file_path):
    df5 = pd.read_excel(file_path)
    covid_2020_12 = df5[df5['전국 기준일'].str.startswith(('2020.12'))]['전국 추가 확진']
    covid_2020_12 = pd.DataFrame(covid_2020_12)
    covid_2020_12_number = covid_2020_12['전국 추가 확진'].sum()
    return covid_2020_12_number


   

def get_data_COVID19_month_2021_01(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_01 = df5[df5['전국 기준일'].str.startswith(('21.01', '2021.01'))]['전국 추가 확진']
    covid_2021_01 = pd.DataFrame(covid_2021_01)
    covid_2021_01_number = covid_2021_01['전국 추가 확진'].sum()
    return covid_2021_01_number

def get_data_COVID19_month_2021_02(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_02 = df5[df5['전국 기준일'].str.startswith(('21.02', '2021.02'))]['전국 추가 확진']
    covid_2021_02 = pd.DataFrame(covid_2021_02)
    covid_2021_02_number = covid_2021_02['전국 추가 확진'].sum()
    return covid_2021_02_number

def get_data_COVID19_month_2021_03(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_03 = df5[df5['전국 기준일'].str.startswith(('2021.03'))]['전국 추가 확진']
    covid_2021_03 = pd.DataFrame(covid_2021_03)
    covid_2021_03_number = covid_2021_03['전국 추가 확진'].sum()
    return covid_2021_03_number
  
def get_data_COVID19_month_2021_04(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_04 = df5[df5['전국 기준일'].str.startswith(('2021.04'))]['전국 추가 확진']
    covid_2021_04 = pd.DataFrame(covid_2021_04)
    covid_2021_04_number = covid_2021_04['전국 추가 확진'].sum()
    return covid_2021_04_number
 
def get_data_COVID19_month_2021_05(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_05 = df5[df5['전국 기준일'].str.startswith(('2021.05'))]['전국 추가 확진']
    covid_2021_05 = pd.DataFrame(covid_2021_05)
    covid_2021_05_number = covid_2021_05['전국 추가 확진'].sum()
    return covid_2021_05_number

def get_data_COVID19_month_2021_06(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_06 = df5[df5['전국 기준일'].str.startswith(('2021.06'))]['전국 추가 확진']
    covid_2021_06 = pd.DataFrame(covid_2021_06)
    covid_2021_06_number = covid_2021_06['전국 추가 확진'].sum()
    return covid_2021_06_number
  
def get_data_COVID19_month_2021_07(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_07 = df5[df5['전국 기준일'].str.startswith(('2021.07'))]['전국 추가 확진']
    covid_2021_07 = pd.DataFrame(covid_2021_07)
    covid_2021_07_number = covid_2021_07['전국 추가 확진'].sum()
    return covid_2021_07_number

def get_data_COVID19_month_2021_08(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_08 = df5[df5['전국 기준일'].str.startswith(('2021.08'))]['전국 추가 확진']
    covid_2021_08 = pd.DataFrame(covid_2021_08)
    covid_2021_08_number = covid_2021_08['전국 추가 확진'].sum()
    return covid_2021_08_number

def get_data_COVID19_month_2021_09(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_09 = df5[df5['전국 기준일'].str.startswith(('2021.09'))]['전국 추가 확진']
    covid_2021_09 = pd.DataFrame(covid_2021_09)
    covid_2021_09_number = covid_2021_09['전국 추가 확진'].sum()
    return covid_2021_09_number

def get_data_COVID19_month_2021_10(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_10 = df5[df5['전국 기준일'].str.startswith(('2021.10'))]['전국 추가 확진']
    covid_2021_10 = pd.DataFrame(covid_2021_10)
    covid_2021_10_number = covid_2021_10['전국 추가 확진'].sum()
    return covid_2021_10_number

def get_data_COVID19_month_2021_11(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_11 = df5[df5['전국 기준일'].str.startswith(('2021.11'))]['전국 추가 확진']
    covid_2021_11 = pd.DataFrame(covid_2021_11)
    covid_2021_11_number = covid_2021_11['전국 추가 확진'].sum()
    return covid_2021_11_number

def get_data_COVID19_month_2021_12(file_path):
    df5 = pd.read_excel(file_path)
    covid_2021_12 = df5[df5['전국 기준일'].str.startswith(('2021.12'))]['전국 추가 확진']
    covid_2021_12 = pd.DataFrame(covid_2021_12)
    covid_2021_12_number = covid_2021_12['전국 추가 확진'].sum()
    return covid_2021_12_number


def get_data_COVID19_month_2022_01(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_01 = df5[df5['전국 기준일'].str.startswith(('22.01', '2022.01'))]['전국 추가 확진']
    covid_2022_01 = pd.DataFrame(covid_2022_01)
    covid_2022_01_number = covid_2022_01['전국 추가 확진'].sum()
    return covid_2022_01_number

def get_data_COVID19_month_2022_02(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_02 = df5[df5['전국 기준일'].str.startswith(('22.02', '2022.02'))]['전국 추가 확진']
    covid_2022_02 = pd.DataFrame(covid_2022_02)
    covid_2022_02_number = covid_2022_02['전국 추가 확진'].sum()
    return covid_2022_02_number

def get_data_COVID19_month_2022_03(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_03 = df5[df5['전국 기준일'].str.startswith(('2022.03'))]['전국 추가 확진']
    covid_2022_03 = pd.DataFrame(covid_2022_03)
    covid_2022_03_number = covid_2022_03['전국 추가 확진'].sum()
    return covid_2022_03_number
  
def get_data_COVID19_month_2022_04(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_04 = df5[df5['전국 기준일'].str.startswith(('2022.04'))]['전국 추가 확진']
    covid_2022_04 = pd.DataFrame(covid_2022_04)
    covid_2022_04_number = covid_2022_04['전국 추가 확진'].sum()
    return covid_2022_04_number
 
def get_data_COVID19_month_2022_05(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_05 = df5[df5['전국 기준일'].str.startswith(('2022.05'))]['전국 추가 확진']
    covid_2022_05 = pd.DataFrame(covid_2022_05)
    covid_2022_05_number = covid_2022_05['전국 추가 확진'].sum()
    return covid_2022_05_number

def get_data_COVID19_month_2022_06(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_06 = df5[df5['전국 기준일'].str.startswith(('2022.06'))]['전국 추가 확진']
    covid_2022_06 = pd.DataFrame(covid_2022_06)
    covid_2022_06_number = covid_2022_06['전국 추가 확진'].sum()
    return covid_2022_06_number
  
def get_data_COVID19_month_2022_07(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_07 = df5[df5['전국 기준일'].str.startswith(('2022.07'))]['전국 추가 확진']
    covid_2022_07 = pd.DataFrame(covid_2022_07)
    covid_2022_07_number = covid_2022_07['전국 추가 확진'].sum()
    return covid_2022_07_number

def get_data_COVID19_month_2022_08(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_08 = df5[df5['전국 기준일'].str.startswith(('2022.08'))]['전국 추가 확진']
    covid_2022_08 = pd.DataFrame(covid_2022_08)
    covid_2022_08_number = covid_2022_08['전국 추가 확진'].sum()
    return covid_2022_08_number

def get_data_COVID19_month_2022_09(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_09 = df5[df5['전국 기준일'].str.startswith(('2022.09'))]['전국 추가 확진']
    covid_2022_09 = pd.DataFrame(covid_2022_09)
    covid_2022_09_number = covid_2022_09['전국 추가 확진'].sum()
    return covid_2022_09_number

def get_data_COVID19_month_2022_10(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_10 = df5[df5['전국 기준일'].str.startswith(('2022.10'))]['전국 추가 확진']
    covid_2022_10 = pd.DataFrame(covid_2022_10)
    covid_2022_10_number = covid_2022_10['전국 추가 확진'].sum()
    return covid_2022_10_number

def get_data_COVID19_month_2022_11(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_11 = df5[df5['전국 기준일'].str.startswith(('2022.11'))]['전국 추가 확진']
    covid_2022_11 = pd.DataFrame(covid_2022_11)
    covid_2022_11_number = covid_2022_11['전국 추가 확진'].sum()
    return covid_2022_11_number

def get_data_COVID19_month_2022_12(file_path):
    df5 = pd.read_excel(file_path)
    covid_2022_12 = df5[df5['전국 기준일'].str.startswith(('2022.12'))]['전국 추가 확진']
    covid_2022_12 = pd.DataFrame(covid_2022_12)
    covid_2022_12_number = covid_2022_12['전국 추가 확진'].sum()
    return covid_2022_12_number




covid_2020_01_number = get_data_COVID19_month_2020_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_02_number = get_data_COVID19_month_2020_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_03_number = get_data_COVID19_month_2020_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_04_number = get_data_COVID19_month_2020_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_05_number = get_data_COVID19_month_2020_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_06_number = get_data_COVID19_month_2020_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_07_number = get_data_COVID19_month_2020_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_08_number = get_data_COVID19_month_2020_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_09_number = get_data_COVID19_month_2020_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_10_number = get_data_COVID19_month_2020_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_11_number = get_data_COVID19_month_2020_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020_12_number = get_data_COVID19_month_2020_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')



covid_2021_01_number = get_data_COVID19_month_2021_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_02_number = get_data_COVID19_month_2021_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_03_number = get_data_COVID19_month_2021_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_04_number = get_data_COVID19_month_2021_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_05_number = get_data_COVID19_month_2021_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_06_number = get_data_COVID19_month_2021_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_07_number = get_data_COVID19_month_2021_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_08_number = get_data_COVID19_month_2021_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_09_number = get_data_COVID19_month_2021_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_10_number = get_data_COVID19_month_2021_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_11_number = get_data_COVID19_month_2021_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2021_12_number = get_data_COVID19_month_2021_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')

covid_2022_01_number = get_data_COVID19_month_2022_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_02_number = get_data_COVID19_month_2022_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_03_number = get_data_COVID19_month_2022_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_04_number = get_data_COVID19_month_2022_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_05_number = get_data_COVID19_month_2022_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_06_number = get_data_COVID19_month_2022_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_07_number = get_data_COVID19_month_2022_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_08_number = get_data_COVID19_month_2022_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_09_number = get_data_COVID19_month_2022_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_10_number = get_data_COVID19_month_2022_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_11_number = get_data_COVID19_month_2022_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2022_12_number = get_data_COVID19_month_2022_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')






covid_2020_month_number = [covid_2020_01_number, covid_2020_02_number, covid_2020_03_number, covid_2020_04_number, covid_2020_05_number, covid_2020_06_number, covid_2020_07_number, covid_2020_08_number, covid_2020_09_number, covid_2020_10_number, covid_2020_11_number, covid_2020_12_number]
covid_2021_month_number = [covid_2021_01_number, covid_2021_02_number, covid_2021_03_number, covid_2021_04_number, covid_2021_05_number, covid_2021_06_number, covid_2021_07_number, covid_2021_08_number, covid_2021_09_number, covid_2021_10_number, covid_2021_11_number, covid_2021_12_number]
covid_2022_month_number = [covid_2022_01_number, covid_2022_02_number, covid_2022_03_number, covid_2022_04_number, covid_2022_05_number, covid_2022_06_number, covid_2022_07_number, covid_2022_08_number, covid_2022_09_number, covid_2022_10_number, covid_2022_11_number, covid_2022_12_number]



def year_movie_graph(data1, data2, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)

    index = [2018, 2019, 2020, 2021, 2022]
    data1 = {'영화관람객수': movie_audience}
    df1 = pd.DataFrame(data1, index=index)
    
    data2 = {'영화매출액': movie_sales}
    df2 = pd.DataFrame(data2, index=index)
    
    fig = plt.figure(figsize=(8,8)) ## Figure 생성
    fig.set_facecolor('white') ## Figure 배경색 지정
    ax1 = fig.add_subplot() ## axes 생성
    colors = sns.color_palette('summer', len(index)) ## 바 차트 색상
    xtick_label_position = list(range(len(index))) ## x축 눈금 라벨이 표시될 x좌표
    ax1.set_xticks(xtick_label_position) ## x축 눈금
    ax1.set_xticklabels(index, fontsize=15) ## x축 눈금 라벨
    ax1.bar(xtick_label_position, df1['영화관람객수'], color=colors) ## 바차트 출력
    ax1.set_xlabel('년도', fontsize=15)
    ax1.set_ylabel('영화관람객수\n(단위 : 억명)', fontsize=15)
    color = 'blue'
    ax2 = ax1.twinx() ## 새로운 axis 생성
    ax2.plot(xtick_label_position, df2['영화매출액'], color=color, linestyle='--', marker='o') ## 선 그래프
    ax2.tick_params(axis='y', labelcolor=color) ## 눈금 라벨 색상 지정
    ax2.set_ylabel('영화매출액\n(단위 : 조)', fontsize=15, rotation = 270, color = 'blue', labelpad=40)
    title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
    plt.title('연도별 영화관람객수/영화매출액', fontsize=20)
    plt.show()




def nationality_movie_numbers_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)
    
    data = {'한국영화관람객수': movie_audience_Korea, '외국영화관람객수' : movie_audience_foreign}
    index = [2018, 2019, 2020, 2021, 2022]
    df = pd.DataFrame(data, index=index)
    
    width = 0.35  # 막대 너비

    plt.bar([i - width/2 for i in df.index], df['한국영화관람객수'], width, label='한국영화관람객수')
    plt.bar([i + width/2 for i in df.index], df['외국영화관람객수'], width, label='외국영화관람객수')
    plt.xlabel('년도', fontsize=13)
    plt.ylabel('국적별영화관람객수\n(단위 : 억명)', fontsize=13)
    title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
    plt.title('국적별 영화관람객수', fontsize=20)
    plt.legend()
    plt.show()
    
    
    
def nationality_movie_sales_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)
    
    data = {'한국영화매출액': movie_sales_Korea, '외국영화매출액' : movie_sales_foreign}
    index = [2018, 2019, 2020, 2021, 2022]
    df = pd.DataFrame(data, index=index)
    
    width = 0.35  # 막대 너비
    
    plt.bar([i - width/2 for i in df.index], df['한국영화매출액'], width,  label='한국영화매출액')
    plt.bar([i + width/2 for i in df.index], df['외국영화매출액'], width,  label='외국영화매출액')
    plt.xlabel('년도', fontsize=13)
    plt.ylabel('국적별영화매출액\n(단위 : 천억)', fontsize=13)
    title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
    plt.title('국적별 영화매출액', fontproperties=title_font)
    plt.legend()
    plt.show()


def COVID19_numbers_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)
    
    data = {'코로나확진자수': covid_number}
    index = [2020, 2021, 2022]
    df = pd.DataFrame(data, index=index)


    plt.plot(df.index, df['코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


    plt.title('코로나 확진자수', fontsize=20)
    plt.xlabel('년도', fontsize=13)
    plt.ylabel('코로나 확진자수\n(단위 : 천만명)', fontsize=13)
    plt.xticks(index, fontsize=15) 

    plt.show()
    

def COVID19_2020_month_numbers_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)

    data = {'2020년 월별 코로나확진자수': covid_2020_month_number}
    index = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
    df = pd.DataFrame(data, index=index)
    



    plt.plot(df.index, df['2020년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


    plt.title('2020년 월별 코로나 확진자수', fontsize=20)
    plt.xlabel('월', fontsize=13)
    plt.ylabel('코로나 확진자수\n(단위 : 명)', fontsize=13)
    plt.xticks(index, fontsize=15) 

    plt.show()
    
def COVID19_2021_month_numbers_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)
    
    data = {'2021년 월별 코로나확진자수': covid_2021_month_number}
    index = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
    df = pd.DataFrame(data, index=index)
    

    plt.plot(df.index, df['2021년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


    plt.title('2021년 월별 코로나 확진자수', fontsize=20)
    plt.xlabel('월', fontsize=13)
    plt.ylabel('코로나 확진자수\n(단위 : 명)', fontsize=13)
    plt.xticks(index, fontsize=15) 

    plt.show()

def COVID19_2022_month_numbers_graph(data, title):
    font_path = "C:/Windows/Fonts/NGULIM.TTF"
    font = font_manager.FontProperties(fname=font_path).get_name()
    rc('font', family=font)
    
    data = {'2022년 월별 코로나확진자수': covid_2022_month_number}
    index = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
    df = pd.DataFrame(data, index=index)
    

    plt.plot(df.index, df['2022년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


    plt.title('2022년 월별 코로나 확진자수', fontsize=20)
    plt.xlabel('월', fontsize=13)
    plt.ylabel('코로나 확진자수\n(단위 : 천만명)', fontsize=13)
    plt.xticks(index, fontsize=15) 
    
    plt.show()






