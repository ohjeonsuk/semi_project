# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 14:52:01 2023

@author: usn14
"""


import pandas as pd


df_2018 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018.xlsx')
df_2018=df_2018.drop(range(0,4))
df_2018 = df_2018.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_2018= df_2018.drop(df_2018[df_2018['매출액 점유율'] == 0].index)
df_2018 = df_2018.dropna(subset=['매출액 점유율'])
movie_audience_2018 = df_2018['관객수'].sum()


df_2019 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019.xlsx')
df_2019=df_2019.drop(range(0,4))
df_2019 = df_2019.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_2019 = df_2019.drop(df_2019[df_2019['매출액 점유율'] == 0].index)
df_2019 = df_2019.dropna(subset=['매출액 점유율'])
movie_audience_2019 = df_2019['관객수'].sum()


df_2020 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020.xlsx')
df_2020=df_2020.drop(range(0,4))
df_2020 = df_2020.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_2020 = df_2020.drop(df_2020[df_2020['매출액 점유율'] == 0].index)
df_2020 = df_2020.dropna(subset=['매출액 점유율'])
movie_audience_2020 = df_2020['관객수'].sum()

df_2021 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021.xlsx')
df_2021=df_2021.drop(range(0,4))
df_2021 = df_2021.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_2021 = df_2021.drop(df_2021[df_2021['매출액 점유율'] == 0].index)
df_2021 = df_2021.dropna(subset=['매출액 점유율'])
movie_audience_2021 = df_2021['관객수'].sum()

df_2022 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022.xlsx')
df_2022=df_2022.drop(range(0,4))
df_2022 = df_2022.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_2022 = df_2022.drop(df_2022[df_2022['매출액 점유율'] == 0].index)
df_2022 = df_2022.dropna(subset=['매출액 점유율'])
movie_audience_2022 = df_2022['관객수'].sum()

movie_audience = [movie_audience_2018, movie_audience_2019, movie_audience_2020, movie_audience_2021, movie_audience_2022]
data1 = {'영화관람객수': movie_audience}
index1 = [2018, 2019, 2020, 2021, 2022]
df1 = pd.DataFrame(data1, index=index1)
#print(df1)

import matplotlib.pyplot as plt
from matplotlib import font_manager, rc
font_path = "C:/Windows/Fonts/NGULIM.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)
plt.bar(df1.index, df1['영화관람객수'])
plt.xlabel('년도', fontsize=13)
plt.ylabel('영화관람객수\n(단위 : 억명)', fontsize=13)
plt.title('연도별 영화관람객수', fontsize=20)
plt.show()

movie_sales_2018 = df_2018['매출액'].sum()
movie_sales_2019 = df_2019['매출액'].sum()
movie_sales_2020 = df_2020['매출액'].sum()
movie_sales_2021 = df_2021['매출액'].sum()
movie_sales_2022 = df_2022['매출액'].sum()
movie_sales = [movie_sales_2018, movie_sales_2019, movie_sales_2020, movie_sales_2021, movie_sales_2022]

import pandas as pd
data2 = {'영화매출액': movie_sales}
index2 = [2018, 2019, 2020, 2021, 2022]
df2 = pd.DataFrame(data2, index=index2)

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
plt.bar(df2.index, df2['영화매출액'])
plt.xlabel('년도', fontsize=13)
plt.ylabel('영화매출액\n(단위 : 조)', fontsize=13)
title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
plt.title('연도별 영화매출액', fontproperties=title_font)
plt.show()

import seaborn as sns

fig = plt.figure(figsize=(8,8)) ## Figure 생성
fig.set_facecolor('white') ## Figure 배경색 지정
ax1 = fig.add_subplot() ## axes 생성
colors = sns.color_palette('summer', len(index1)) ## 바 차트 색상
xtick_label_position = list(range(len(index1))) ## x축 눈금 라벨이 표시될 x좌표
ax1.set_xticks(xtick_label_position) ## x축 눈금
ax1.set_xticklabels(index1, fontsize=15) ## x축 눈금 라벨
ax1.bar(xtick_label_position, df1['영화관람객수'], color=colors) ## 바차트 출력
ax1.set_xlabel('년도', fontsize=15)
ax1.set_ylabel('영화관람객수\n(단위 : 억명)', fontsize=15)
color = 'blue'
ax2 = ax1.twinx() ## 새로운 axis 생성
ax2.plot(xtick_label_position, df2['영화매출액'], color=color, linestyle='--', marker='o') ## 선 그래프
ax2.tick_params(axis='y', labelcolor=color) ## 눈금 라벨 색상 지정
ax2.set_ylabel('영화매출액\n(단위 : 조)', fontsize=15, rotation = 270, color = 'blue', labelpad=40)
title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
plt.title('연도별 영화관람객수/영화매출액', fontsize = 20)
plt.show()

df_Korea_2018 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_한국.xlsx')
df_Korea_2018 = df_Korea_2018.drop(range(0,4))
df_Korea_2018 = df_Korea_2018.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_Korea_2018 = df_Korea_2018.drop(df_Korea_2018[df_Korea_2018['매출액 점유율'] == 0].index)
df_Korea_2018 = df_Korea_2018.dropna(subset=['매출액 점유율'])
movie_audience_Korea_2018 = df_Korea_2018['관객수'].sum()
movie_sales_Korea_2018 = df_Korea_2018['매출액'].sum()

df_Korea_2019 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_한국.xlsx')
df_Korea_2019 = df_Korea_2019.drop(range(0,4))
df_Korea_2019 = df_Korea_2019.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_Korea_2019 = df_Korea_2019.drop(df_Korea_2019[df_Korea_2019['매출액 점유율'] == 0].index)
df_Korea_2019 = df_Korea_2019.dropna(subset=['매출액 점유율'])
movie_audience_Korea_2019 = df_Korea_2019['관객수'].sum()
movie_sales_Korea_2019 = df_Korea_2019['매출액'].sum()

df_Korea_2020 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_한국.xlsx')
df_Korea_2020 = df_Korea_2020.drop(range(0,4))
df_Korea_2020 = df_Korea_2020.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_Korea_2020 = df_Korea_2020.drop(df_Korea_2020[df_Korea_2020['매출액 점유율'] == 0].index)
df_Korea_2020 = df_Korea_2020.dropna(subset=['매출액 점유율'])
movie_audience_Korea_2020 = df_Korea_2020['관객수'].sum()
movie_sales_Korea_2020 = df_Korea_2020['매출액'].sum()

df_Korea_2021 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_한국.xlsx')
df_Korea_2021 = df_Korea_2021.drop(range(0,4))
df_Korea_2021 = df_Korea_2021.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_Korea_2021 = df_Korea_2021.drop(df_Korea_2021[df_Korea_2021['매출액 점유율'] == 0].index)
df_Korea_2021 = df_Korea_2021.dropna(subset=['매출액 점유율'])
movie_audience_Korea_2021 = df_Korea_2021['관객수'].sum()
movie_sales_Korea_2021 = df_Korea_2021['매출액'].sum()

df_Korea_2022 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_한국.xlsx')
df_Korea_2022 = df_Korea_2022.drop(range(0,4))
df_Korea_2022 = df_Korea_2022.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_Korea_2022 = df_Korea_2022.drop(df_Korea_2022[df_Korea_2022['매출액 점유율'] == 0].index)
df_Korea_2022 = df_Korea_2022.dropna(subset=['매출액 점유율'])
movie_audience_Korea_2022 = df_Korea_2022['관객수'].sum()
movie_sales_Korea_2022 = df_Korea_2022['매출액'].sum()

movie_audience_Korea = [movie_audience_Korea_2018, movie_audience_Korea_2019, movie_audience_Korea_2020, movie_audience_Korea_2021, movie_audience_Korea_2022]
#print(movie_audience_Korea)

movie_sales_Korea = [movie_sales_Korea_2018, movie_sales_Korea_2019, movie_sales_Korea_2020, movie_sales_Korea_2021, movie_sales_Korea_2022]
#print(movie_sales_Korea)

df_foreign_2018 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_외국.xlsx')
df_foreign_2018 = df_foreign_2018.drop(range(0,4))
df_foreign_2018 = df_foreign_2018.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_foreign_2018 = df_foreign_2018.drop(df_foreign_2018[df_foreign_2018['매출액 점유율'] == 0].index)
df_foreign_2018 = df_foreign_2018.dropna(subset=['매출액 점유율'])
movie_audience_foreign_2018 = df_foreign_2018['관객수'].sum()
movie_sales_foreign_2018 = df_foreign_2018['매출액'].sum()

df_foreign_2019 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_외국.xlsx')
df_foreign_2019 = df_foreign_2019.drop(range(0,4))
df_foreign_2019 = df_foreign_2019.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_foreign_2019 = df_foreign_2019.drop(df_foreign_2019[df_foreign_2019['매출액 점유율'] == 0].index)
df_foreign_2019 = df_foreign_2019.dropna(subset=['매출액 점유율'])
movie_audience_foreign_2019 = df_foreign_2019['관객수'].sum()
movie_sales_foreign_2019 = df_foreign_2019['매출액'].sum()

df_foreign_2020 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_외국.xlsx')
df_foreign_2020 = df_foreign_2020.drop(range(0,4))
df_foreign_2020 = df_foreign_2020.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_foreign_2020 = df_foreign_2020.drop(df_foreign_2020[df_foreign_2020['매출액 점유율'] == 0].index)
df_foreign_2020 = df_foreign_2020.dropna(subset=['매출액 점유율'])
movie_audience_foreign_2020 = df_foreign_2020['관객수'].sum()
movie_sales_foreign_2020 = df_foreign_2020['매출액'].sum()

df_foreign_2021 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_외국.xlsx')
df_foreign_2021 = df_foreign_2021.drop(range(0,4))
df_foreign_2021 = df_foreign_2021.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_foreign_2021 = df_foreign_2021.drop(df_foreign_2021[df_foreign_2021['매출액 점유율'] == 0].index)
df_foreign_2021 = df_foreign_2021.dropna(subset=['매출액 점유율'])
movie_audience_foreign_2021 = df_foreign_2021['관객수'].sum()
movie_sales_foreign_2021 = df_foreign_2021['매출액'].sum()

df_foreign_2022 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_외국.xlsx')
df_foreign_2022 = df_foreign_2022.drop(range(0,4))
df_foreign_2022 = df_foreign_2022.rename(columns={'■ 연도별 박스오피스': '순위', 'Unnamed: 1': '영화명', 'Unnamed: 2': '개봉일', 'Unnamed: 3': '매출액', 'Unnamed: 4': '매출액 점유율', 'Unnamed: 5': '관객수', 'Unnamed: 6': '스크린수', 'Unnamed: 7': '상영횟수', 'Unnamed: 8': '대표국적', 'Unnamed: 9': '국적', 'Unnamed: 10': '배급사'})
df_foreign_2022 = df_foreign_2022.drop(df_foreign_2022[df_foreign_2022['매출액 점유율'] == 0].index)
df_foreign_2022 = df_foreign_2022.dropna(subset=['매출액 점유율'])
movie_audience_foreign_2022 = df_foreign_2022['관객수'].sum()
movie_sales_foreign_2022 = df_foreign_2022['매출액'].sum()

movie_audience_foreign = [movie_audience_foreign_2018, movie_audience_foreign_2019, movie_audience_foreign_2020, movie_audience_foreign_2021, movie_audience_foreign_2022]
movie_sales_foreign = [movie_sales_foreign_2018, movie_sales_foreign_2019, movie_sales_foreign_2020, movie_sales_foreign_2021, movie_sales_foreign_2022]


import pandas as pd
data3 = {'한국영화관람객수': movie_audience_Korea, '외국영화관람객수' : movie_audience_foreign}
index3 = [2018, 2019, 2020, 2021, 2022]
df3 = pd.DataFrame(data3, index=index3)

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
width = 0.35  # 막대 너비

plt.bar([i - width/2 for i in df3.index], df3['한국영화관람객수'], width, label='한국영화관람객수')
plt.bar([i + width/2 for i in df3.index], df3['외국영화관람객수'], width, label='외국영화관람객수')
plt.xlabel('년도', fontsize=13)
plt.ylabel('국적별영화관람객수\n(단위 : 억명)', fontsize=13)
title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
plt.title('국적별 영화관람객수', fontproperties=title_font)
plt.legend()
plt.show()

import pandas as pd
data4 = {'한국영화매출액': movie_sales_Korea, '외국영화매출액' : movie_sales_foreign}
index4 = [2018, 2019, 2020, 2021, 2022]
df4 = pd.DataFrame(data4, index=index4)

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
width = 0.35  # 막대 너비
plt.bar([i - width/2 for i in df4.index], df4['한국영화매출액'], width,  label='한국영화매출액')
plt.bar([i + width/2 for i in df4.index], df4['외국영화매출액'], width,  label='외국영화매출액')
plt.xlabel('년도', fontsize=13)
plt.ylabel('국적별영화매출액\n(단위 : 천억)', fontsize=13)
title_font = FontProperties(weight='bold', size=20)  # 글꼴 두껍게 설정 및 크기 설정
plt.title('국적별 영화매출액', fontproperties=title_font)
plt.legend()
plt.show()

import pandas as pd
df5 = pd.read_excel('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
covid_2020 = df5[df5['전국 기준일'].str.startswith(('20.', '2020.'))]['전국 추가 확진']
covid_2020 = pd.DataFrame(covid_2020)
covid_2020_number = covid_2020['전국 추가 확진'].sum()

covid_2020_01 = df5[df5['전국 기준일'].str.startswith(('20.01', '2020.01'))]['전국 추가 확진']
covid_2020_01 = pd.DataFrame(covid_2020_01)
covid_2020_01_number = covid_2020_01['전국 추가 확진'].sum()
print(covid_2020_01_number)

covid_2020_02 = df5[df5['전국 기준일'].str.startswith(('20.02', '2020.02'))]['전국 추가 확진']
covid_2020_02 = pd.DataFrame(covid_2020_02)
covid_2020_02_number = covid_2020_02['전국 추가 확진'].sum()
print(covid_2020_02_number)

covid_2020_03 = df5[df5['전국 기준일'].str.startswith(('2020.03'))]['전국 추가 확진']
covid_2020_03 = pd.DataFrame(covid_2020_03)
covid_2020_03_number = covid_2020_03['전국 추가 확진'].sum()
print(covid_2020_03_number)

covid_2020_04 = df5[df5['전국 기준일'].str.startswith(('2020.04'))]['전국 추가 확진']
covid_2020_04 = pd.DataFrame(covid_2020_04)
covid_2020_04_number = covid_2020_04['전국 추가 확진'].sum()
print(covid_2020_04_number)

covid_2020_05 = df5[df5['전국 기준일'].str.startswith(('2020.05'))]['전국 추가 확진']
covid_2020_05 = pd.DataFrame(covid_2020_05)
covid_2020_05_number = covid_2020_05['전국 추가 확진'].sum()
print(covid_2020_05_number)

covid_2020_06 = df5[df5['전국 기준일'].str.startswith(('2020.06'))]['전국 추가 확진']
covid_2020_06 = pd.DataFrame(covid_2020_06)
covid_2020_06_number = covid_2020_06['전국 추가 확진'].sum()
print(covid_2020_06_number)

covid_2020_07 = df5[df5['전국 기준일'].str.startswith(('2020.07'))]['전국 추가 확진']
covid_2020_07 = pd.DataFrame(covid_2020_07)
covid_2020_07_number = covid_2020_07['전국 추가 확진'].sum()
print(covid_2020_07_number)

covid_2020_08 = df5[df5['전국 기준일'].str.startswith(('2020.08'))]['전국 추가 확진']
covid_2020_08 = pd.DataFrame(covid_2020_08)
covid_2020_08_number = covid_2020_08['전국 추가 확진'].sum()
print(covid_2020_08_number)

covid_2020_09 = df5[df5['전국 기준일'].str.startswith(('2020.09'))]['전국 추가 확진']
covid_2020_09 = pd.DataFrame(covid_2020_09)
covid_2020_09_number = covid_2020_09['전국 추가 확진'].sum()
print(covid_2020_09_number)

covid_2020_10 = df5[df5['전국 기준일'].str.startswith(('2020.10'))]['전국 추가 확진']
covid_2020_10 = pd.DataFrame(covid_2020_10)
covid_2020_10_number = covid_2020_10['전국 추가 확진'].sum()
print(covid_2020_10_number)

covid_2020_11 = df5[df5['전국 기준일'].str.startswith(('2020.11'))]['전국 추가 확진']
covid_2020_11 = pd.DataFrame(covid_2020_11)
covid_2020_11_number = covid_2020_11['전국 추가 확진'].sum()
print(covid_2020_11_number)

covid_2020_12 = df5[df5['전국 기준일'].str.startswith(('2020.12'))]['전국 추가 확진']
covid_2020_12 = pd.DataFrame(covid_2020_12)
covid_2020_12_number = covid_2020_12['전국 추가 확진'].sum()
print(covid_2020_12_number)




covid_2021 = df5[df5['전국 기준일'].str.startswith(('2021.'))]['전국 추가 확진']
covid_2021 = pd.DataFrame(covid_2021)
covid_2021_number = covid_2021['전국 추가 확진'].sum()

covid_2021_01 = df5[df5['전국 기준일'].str.startswith(('2021.01'))]['전국 추가 확진']
covid_2021_01 = pd.DataFrame(covid_2021_01)
covid_2021_01_number = covid_2021_01['전국 추가 확진'].sum()
print(covid_2021_01_number)

covid_2021_02 = df5[df5['전국 기준일'].str.startswith(('2021.02'))]['전국 추가 확진']
covid_2021_02 = pd.DataFrame(covid_2021_02)
covid_2021_02_number = covid_2021_02['전국 추가 확진'].sum()
print(covid_2021_02_number)

covid_2021_03 = df5[df5['전국 기준일'].str.startswith(('2021.03'))]['전국 추가 확진']
covid_2021_03 = pd.DataFrame(covid_2021_03)
covid_2021_03_number = covid_2021_03['전국 추가 확진'].sum()
print(covid_2021_03_number)

covid_2021_04 = df5[df5['전국 기준일'].str.startswith(('2021.04'))]['전국 추가 확진']
covid_2021_04 = pd.DataFrame(covid_2021_04)
covid_2021_04_number = covid_2021_04['전국 추가 확진'].sum()
print(covid_2021_04_number)

covid_2021_05 = df5[df5['전국 기준일'].str.startswith(('2021.05'))]['전국 추가 확진']
covid_2021_05 = pd.DataFrame(covid_2021_05)
covid_2021_05_number = covid_2021_05['전국 추가 확진'].sum()
print(covid_2021_05_number)

covid_2021_06 = df5[df5['전국 기준일'].str.startswith(('2021.06'))]['전국 추가 확진']
covid_2021_06 = pd.DataFrame(covid_2021_06)
covid_2021_06_number = covid_2021_06['전국 추가 확진'].sum()
print(covid_2021_06_number)

covid_2021_07 = df5[df5['전국 기준일'].str.startswith(('2021.07'))]['전국 추가 확진']
covid_2021_07 = pd.DataFrame(covid_2021_07)
covid_2021_07_number = covid_2021_07['전국 추가 확진'].sum()
print(covid_2021_07_number)

covid_2021_08 = df5[df5['전국 기준일'].str.startswith(('2021.08'))]['전국 추가 확진']
covid_2021_08 = pd.DataFrame(covid_2021_08)
covid_2021_08_number = covid_2021_08['전국 추가 확진'].sum()
print(covid_2021_08_number)

covid_2021_09 = df5[df5['전국 기준일'].str.startswith(('2021.09'))]['전국 추가 확진']
covid_2021_09 = pd.DataFrame(covid_2021_09)
covid_2021_09_number = covid_2021_09['전국 추가 확진'].sum()
print(covid_2021_09_number)

covid_2021_10 = df5[df5['전국 기준일'].str.startswith(('2021.10'))]['전국 추가 확진']
covid_2021_10 = pd.DataFrame(covid_2021_10)
covid_2021_10_number = covid_2021_10['전국 추가 확진'].sum()
print(covid_2021_10_number)

covid_2021_11 = df5[df5['전국 기준일'].str.startswith(('2021.11'))]['전국 추가 확진']
covid_2021_11 = pd.DataFrame(covid_2021_11)
covid_2021_11_number = covid_2021_11['전국 추가 확진'].sum()
print(covid_2021_11_number)

covid_2021_12 = df5[df5['전국 기준일'].str.startswith(('2021.12'))]['전국 추가 확진']
covid_2021_12 = pd.DataFrame(covid_2021_12)
covid_2021_12_number = covid_2021_12['전국 추가 확진'].sum()
print(covid_2021_12_number)



covid_2022 = df5[df5['전국 기준일'].str.startswith(('2022.'))]['전국 추가 확진']
covid_2022 = pd.DataFrame(covid_2022)
covid_2022_number = covid_2022['전국 추가 확진'].sum()

covid_2022_01 = df5[df5['전국 기준일'].str.startswith(('2022.01'))]['전국 추가 확진']
covid_2022_01 = pd.DataFrame(covid_2022_01)
covid_2022_01_number = covid_2022_01['전국 추가 확진'].sum()
print(covid_2022_01_number)

covid_2022_02 = df5[df5['전국 기준일'].str.startswith(('2022.02'))]['전국 추가 확진']
covid_2022_02 = pd.DataFrame(covid_2022_02)
covid_2022_02_number = covid_2022_02['전국 추가 확진'].sum()
print(covid_2022_02_number)

covid_2022_03 = df5[df5['전국 기준일'].str.startswith(('2022.03'))]['전국 추가 확진']
covid_2022_03 = pd.DataFrame(covid_2022_03)
covid_2022_03_number = covid_2022_03['전국 추가 확진'].sum()
print(covid_2022_03_number)

covid_2022_04 = df5[df5['전국 기준일'].str.startswith(('2022.04'))]['전국 추가 확진']
covid_2022_04 = pd.DataFrame(covid_2022_04)
covid_2022_04_number = covid_2022_04['전국 추가 확진'].sum()
print(covid_2022_04_number)

covid_2022_05 = df5[df5['전국 기준일'].str.startswith(('2022.05'))]['전국 추가 확진']
covid_2022_05 = pd.DataFrame(covid_2022_05)
covid_2022_05_number = covid_2022_05['전국 추가 확진'].sum()
print(covid_2022_05_number)

covid_2022_06 = df5[df5['전국 기준일'].str.startswith(('2022.06'))]['전국 추가 확진']
covid_2022_06 = pd.DataFrame(covid_2022_06)
covid_2022_06_number = covid_2022_06['전국 추가 확진'].sum()
print(covid_2022_06_number)

covid_2022_07 = df5[df5['전국 기준일'].str.startswith(('2022.07'))]['전국 추가 확진']
covid_2022_07 = pd.DataFrame(covid_2022_07)
covid_2022_07_number = covid_2022_07['전국 추가 확진'].sum()
print(covid_2022_07_number)

covid_2022_08 = df5[df5['전국 기준일'].str.startswith(('2022.08'))]['전국 추가 확진']
covid_2022_08 = pd.DataFrame(covid_2022_08)
covid_2022_08_number = covid_2022_08['전국 추가 확진'].sum()
print(covid_2022_08_number)

covid_2022_09 = df5[df5['전국 기준일'].str.startswith(('2022.09'))]['전국 추가 확진']
covid_2022_09 = pd.DataFrame(covid_2022_09)
covid_2022_09_number = covid_2022_09['전국 추가 확진'].sum()
print(covid_2022_09_number)

covid_2022_10 = df5[df5['전국 기준일'].str.startswith(('2022.10'))]['전국 추가 확진']
covid_2022_10 = pd.DataFrame(covid_2022_10)
covid_2022_10_number = covid_2022_10['전국 추가 확진'].sum()
print(covid_2022_10_number)

covid_2022_11 = df5[df5['전국 기준일'].str.startswith(('2022.11'))]['전국 추가 확진']
covid_2022_11 = pd.DataFrame(covid_2022_11)
covid_2022_11_number = covid_2022_11['전국 추가 확진'].sum()
print(covid_2022_11_number)

covid_2022_12 = df5[df5['전국 기준일'].str.startswith(('2022.12'))]['전국 추가 확진']
covid_2022_12 = pd.DataFrame(covid_2022_12)
covid_2022_12_number = covid_2022_12['전국 추가 확진'].sum()
print(covid_2022_12_number)

covid_2020_month_number = [covid_2020_01_number, covid_2020_02_number, covid_2020_03_number, covid_2020_04_number, covid_2020_05_number, covid_2020_06_number, covid_2020_07_number, covid_2020_08_number, covid_2020_09_number, covid_2020_10_number, covid_2020_11_number, covid_2020_12_number]
covid_2021_month_number = [covid_2021_01_number, covid_2021_02_number, covid_2021_03_number, covid_2021_04_number, covid_2021_05_number, covid_2021_06_number, covid_2021_07_number, covid_2021_08_number, covid_2021_09_number, covid_2021_10_number, covid_2021_11_number, covid_2021_12_number]
covid_2022_month_number = [covid_2022_01_number, covid_2022_02_number, covid_2022_03_number, covid_2022_04_number, covid_2022_05_number, covid_2022_06_number, covid_2022_07_number, covid_2022_08_number, covid_2022_09_number, covid_2022_10_number, covid_2022_11_number, covid_2022_12_number]
covid_number = [covid_2020_number, covid_2021_number, covid_2022_number]


import pandas as pd
import matplotlib.pyplot as plt

data5 = {'코로나확진자수': covid_number}
index5 = [2020, 2021, 2022]
df5 = pd.DataFrame(data5, index=index5)


plt.plot(df5.index, df5['코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


plt.title('코로나 확진자수', fontsize=20)
plt.xlabel('년도', fontsize=13)
plt.ylabel('코로나 확진자수\n(단위 : 천만명)', fontsize=13)
plt.xticks(index5, fontsize=15) 

plt.show()


import pandas as pd
import matplotlib.pyplot as plt

data6 = {'2020년 월별 코로나확진자수': covid_2020_month_number}
index6 = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
df6 = pd.DataFrame(data6, index=index6)


plt.plot(df6.index, df6['2020년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


plt.title('2020년 월별 코로나 확진자수', fontsize=20)
plt.xlabel('월', fontsize=13)
plt.ylabel('코로나 확진자수\n(단위 : 명)', fontsize=13)
plt.xticks(index6, fontsize=15) 

plt.show()


import pandas as pd
import matplotlib.pyplot as plt

data7 = {'2021년 월별 코로나확진자수': covid_2021_month_number}
index7 = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
df7 = pd.DataFrame(data7, index=index7)


plt.plot(df7.index, df7['2021년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


plt.title('2021년 월별 코로나 확진자수', fontsize=20)
plt.xlabel('월', fontsize=13)
plt.ylabel('코로나 확진자수\n(단위 : 명)', fontsize=13)
plt.xticks(index7, fontsize=15) 

plt.show()

import pandas as pd
import matplotlib.pyplot as plt

data8 = {'2022년 월별 코로나확진자수': covid_2022_month_number}
index8 = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
df8 = pd.DataFrame(data8, index=index8)


plt.plot(df8.index, df8['2022년 월별 코로나확진자수'], marker='o')  # marker 옵션으로 데이터 포인트를 표시할 수 있음


plt.title('2022년 월별 코로나 확진자수', fontsize=20)
plt.xlabel('월', fontsize=13)
plt.ylabel('코로나 확진자수\n(단위 : 천만명)', fontsize=13)
plt.xticks(index8, fontsize=15) 

plt.show()