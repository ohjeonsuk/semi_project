# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 17:03:18 2023

@author: Jung
"""

from utils import module as mo
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import font_manager
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import FuncFormatter, MaxNLocator
from matplotlib.font_manager import FontProperties

def app():    
    
    movie_sales_2018, movie_audience_2018 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018.xlsx')
    movie_sales_2019, movie_audience_2019 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019.xlsx')
    movie_sales_2020, movie_audience_2020 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020.xlsx')
    movie_sales_2021, movie_audience_2021 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021.xlsx')
    movie_sales_2022, movie_audience_2022 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022.xlsx')
    movie_audience = [movie_audience_2018, movie_audience_2019, movie_audience_2020, movie_audience_2021, movie_audience_2022]
    movie_sales = [movie_sales_2018, movie_sales_2019, movie_sales_2020, movie_sales_2021, movie_sales_2022]
    year = [2018, 2019, 2020, 2021, 2022]
    
    
    movie_audience_Korea_2018, movie_sales_Korea_2018 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_한국.xlsx')
    movie_audience_Korea_2019, movie_sales_Korea_2019 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_한국.xlsx')
    movie_audience_Korea_2020, movie_sales_Korea_2020 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_한국.xlsx')
    movie_audience_Korea_2021, movie_sales_Korea_2021 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_한국.xlsx')
    movie_audience_Korea_2022, movie_sales_Korea_2022 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_한국.xlsx')
    movie_audience_Korea = [movie_audience_Korea_2018, movie_audience_Korea_2019, movie_audience_Korea_2020, movie_audience_Korea_2021, movie_audience_Korea_2022]
    movie_sales_Korea = [movie_sales_Korea_2018, movie_sales_Korea_2019, movie_sales_Korea_2020, movie_sales_Korea_2021, movie_sales_Korea_2022]

    movie_audience_foreign_2018, movie_sales_foreign_2018 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2018_외국.xlsx')
    movie_audience_foreign_2019, movie_sales_foreign_2019 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2019_외국.xlsx')
    movie_audience_foreign_2020, movie_sales_foreign_2020 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2020_외국.xlsx')
    movie_audience_foreign_2021, movie_sales_foreign_2021 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2021_외국.xlsx')
    movie_audience_foreign_2022, movie_sales_foreign_2022 = mo.get_data('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\영화데이터/KOBIS_연도별박스오피스_2022_외국.xlsx')
    movie_audience_foreign = [movie_audience_foreign_2018, movie_audience_foreign_2019, movie_audience_foreign_2020, movie_audience_foreign_2021, movie_audience_foreign_2022]
    movie_sales_foreign = [movie_sales_foreign_2018, movie_sales_foreign_2019, movie_sales_foreign_2020, movie_sales_foreign_2021, movie_sales_foreign_2022]
    year = [2018, 2019, 2020, 2021, 2022]
    
    covid_2020_number = mo.get_data_COVID19_2020('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_number = mo.get_data_COVID19_2021('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_number = mo.get_data_COVID19_2022('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')

    covid_number = [covid_2020_number, covid_2021_number, covid_2022_number]
    
    covid_2020_01_number = mo.get_data_COVID19_month_2020_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_02_number = mo.get_data_COVID19_month_2020_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_03_number = mo.get_data_COVID19_month_2020_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_04_number = mo.get_data_COVID19_month_2020_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_05_number = mo.get_data_COVID19_month_2020_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_06_number = mo.get_data_COVID19_month_2020_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_07_number = mo.get_data_COVID19_month_2020_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_08_number = mo.get_data_COVID19_month_2020_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_09_number = mo.get_data_COVID19_month_2020_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_10_number = mo.get_data_COVID19_month_2020_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_11_number = mo.get_data_COVID19_month_2020_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2020_12_number = mo.get_data_COVID19_month_2020_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')



    covid_2021_01_number = mo.get_data_COVID19_month_2021_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_02_number = mo.get_data_COVID19_month_2021_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_03_number = mo.get_data_COVID19_month_2021_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_04_number = mo.get_data_COVID19_month_2021_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_05_number = mo.get_data_COVID19_month_2021_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_06_number = mo.get_data_COVID19_month_2021_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_07_number = mo.get_data_COVID19_month_2021_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_08_number = mo.get_data_COVID19_month_2021_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_09_number = mo.get_data_COVID19_month_2021_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_10_number = mo.get_data_COVID19_month_2021_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_11_number = mo.get_data_COVID19_month_2021_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2021_12_number = mo.get_data_COVID19_month_2021_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')

    covid_2022_01_number = mo.get_data_COVID19_month_2022_01('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_02_number = mo.get_data_COVID19_month_2022_02('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_03_number = mo.get_data_COVID19_month_2022_03('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_04_number = mo.get_data_COVID19_month_2022_04('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_05_number = mo.get_data_COVID19_month_2022_05('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_06_number = mo.get_data_COVID19_month_2022_06('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_07_number = mo.get_data_COVID19_month_2022_07('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_08_number = mo.get_data_COVID19_month_2022_08('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_09_number = mo.get_data_COVID19_month_2022_09('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_10_number = mo.get_data_COVID19_month_2022_10('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_11_number = mo.get_data_COVID19_month_2022_11('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')
    covid_2022_12_number = mo.get_data_COVID19_month_2022_12('C:\\Users\\usn14\\.spyder-py3\\python_basic\\semi_project\\코로나19데이터/코로나19_확진자_발생동향.xlsx')






    covid_2020_month_number = [covid_2020_01_number, covid_2020_02_number, covid_2020_03_number, covid_2020_04_number, covid_2020_05_number, covid_2020_06_number, covid_2020_07_number, covid_2020_08_number, covid_2020_09_number, covid_2020_10_number, covid_2020_11_number, covid_2020_12_number]
    covid_2021_month_number = [covid_2021_01_number, covid_2021_02_number, covid_2021_03_number, covid_2021_04_number, covid_2021_05_number, covid_2021_06_number, covid_2021_07_number, covid_2021_08_number, covid_2021_09_number, covid_2021_10_number, covid_2021_11_number, covid_2021_12_number]
    covid_2022_month_number = [covid_2022_01_number, covid_2022_02_number, covid_2022_03_number, covid_2022_04_number, covid_2022_05_number, covid_2022_06_number, covid_2022_07_number, covid_2022_08_number, covid_2022_09_number, covid_2022_10_number, covid_2022_11_number, covid_2022_12_number]
    
    
    st.write('연도별 영화관람객수/영화매출액')
    data = {'영화관람객수': movie_audience}
    data2 =  {'영화매출액': movie_sales}
    year_movie = mo.year_movie_graph(data, data2, '연도별 영화관람객수 영화매출액')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(year_movie)

    
    
    st.write('국적별 영화관람객수')
    data = {'한국영화관람객수': movie_audience_Korea, '외국영화관람객수' : movie_audience_foreign}
    nationality_movie_numbers = mo.nationality_movie_numbers_graph(data, '국적별 영화관람객수')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(nationality_movie_numbers)
    
    
    st.write('국적별 영화매출액')
    data = {'한국영화매출액': movie_sales_Korea, '외국영화매출액' : movie_sales_foreign}
    nationality_movie_sales = mo.nationality_movie_sales_graph(data, '국적별 영화매출액')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(nationality_movie_sales)
    
    st.write('연도별 코로나확진자수')
    data = {'코로나확진자수': covid_number}
    COVID19_numbers = mo.COVID19_numbers_graph(data, '국적별 영화관람객수')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(COVID19_numbers)
    
    st.write('2020년 월별 코로나확진자수')
    data = {'2020년 월별 코로나확진자수': covid_2020_month_number}
    COVID19_2020_month_numbers = mo.COVID19_2020_month_numbers_graph(data, '2020년 월별 코로나확진자수')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(COVID19_2020_month_numbers)
    
    st.write('2021년 월별 코로나확진자수')
    data = {'2021년 월별 코로나확진자수': covid_2021_month_number}
    COVID19_2021_month_numbers = mo.COVID19_2021_month_numbers_graph(data, '2021년 월별 코로나확진자수')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(COVID19_2021_month_numbers)
    
    st.write('2022년 월별 코로나확진자수')
    data = {'2022년 월별 코로나확진자수': covid_2022_month_number}
    COVID19_2022_month_numbers = mo.COVID19_2022_month_numbers_graph(data, '2022년 월별 코로나확진자수')
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.pyplot(COVID19_2022_month_numbers)
    

    
    
    #data_audience_korea = dict(zip(year, movie_audience_Korea))
    #data_audience_foreign = dict(zip(year, movie_audience_foreign))
    #fig_audience, _ = mo.nationality_movie_numbers_graph(data_audience_korea, '국적별 영화관람객수')
    #st.pyplot(fig_audience)
    
    
    #data_sales_korea = dict(zip(year, movie_sales_Korea))
    #data_sales_foreign = dict(zip(year, movie_sales_foreign))
    #fig_sales, _ = mo.nationality_movie_sales_graph(data_sales_korea, '국적별 영화매출액')
    #st.pyplot(fig_sales)
    
    #data_sales_ind = dict(zip(year, movie_audience))
    #data_sales_com = dict(zip(year, movie_sales))
    #fig_sales, _ = mo.create_sales_graph(data_sales_ind, '최근 5년 간 일반/독립 영화 매출액(단위:억)')
    #st.pyplot(fig_sales)
    
    
    #data_aud_ind = dict(zip(year, aud_ind))
    #data_aud_com = dict(zip(year, aud_com))
    #fig_aud, _ = mo.create_aud_graph(data_aud_ind, '최근 5년 간 일반/독립 영화 관객수(단위:백만)')
    #st.pyplot(fig_aud)
    
    