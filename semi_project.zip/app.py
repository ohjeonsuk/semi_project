# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 16:28:02 2023

@author: Jung
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from utils import module as mo
from page import page as pg

st.title('세미 프로젝트 (6조)')



item = st.sidebar.selectbox('항목을 골라요', ['프로젝트 다이어그램', '처리 및 분석한 내용'])


if item == '처리 및 분석한 내용':
    pg.app()
